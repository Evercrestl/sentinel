{
  "name": "CaseUpdate",
  "type": "object",
  "properties": {
    "case_id": {
      "type": "string",
      "description": "Associated case ID"
    },
    "title": {
      "type": "string",
      "description": "Update title"
    },
    "description": {
      "type": "string",
      "description": "Detailed description of the update"
    },
    "status_change": {
      "type": "string",
      "enum": [
        "submitted",
        "under_review",
        "investigating",
        "recovery_in_progress",
        "resolved",
        "closed"
      ],
      "description": "New status if changed"
    },
    "update_type": {
      "type": "string",
      "enum": [
        "status_change",
        "note",
        "evidence_added",
        "recovery_update",
        "assignment"
      ],
      "description": "Type of update"
    }
  },
  "required": [
    "case_id",
    "title",
    "description"
  ],
  "rls": {
    "create": {
      "$or": [
        {
          "created_by": "{{user.email}}"
        },
        {
          "user_condition": {
            "role": "admin"
          }
        }
      ]
    },
    "read": {
      "$or": [
        {
          "created_by": "{{user.email}}"
        },
        {
          "user_condition": {
            "role": "admin"
          }
        }
      ]
    },
    "update": {
      "$or": [
        {
          "created_by": "{{user.email}}"
        },
        {
          "user_condition": {
            "role": "admin"
          }
        }
      ]
    },
    "delete": {
      "user_condition": {
        "role": "admin"
      }
    }
  }
}