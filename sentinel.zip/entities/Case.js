{
  "name": "Case",
  "type": "object",
  "properties": {
    "case_id": {
      "type": "string",
      "description": "Unique case identifier (e.g. FR-2026-00001)"
    },
    "full_name": {
      "type": "string",
      "description": "Full name of the complainant"
    },
    "email": {
      "type": "string",
      "description": "Email address"
    },
    "phone": {
      "type": "string",
      "description": "Phone number"
    },
    "scam_type": {
      "type": "string",
      "enum": [
        "investment",
        "romance",
        "crypto",
        "phishing",
        "identity_theft",
        "employment",
        "tech_support",
        "online_shopping",
        "lottery",
        "other"
      ],
      "description": "Type of scam"
    },
    "description": {
      "type": "string",
      "description": "Detailed description of the incident"
    },
    "amount_lost": {
      "type": "number",
      "description": "Amount lost in USD"
    },
    "currency": {
      "type": "string",
      "enum": [
        "USD",
        "EUR",
        "GBP",
        "CAD",
        "AUD",
        "BTC",
        "ETH",
        "OTHER"
      ],
      "default": "USD"
    },
    "date_of_incident": {
      "type": "string",
      "format": "date",
      "description": "When the scam occurred"
    },
    "evidence_files": {
      "type": "array",
      "items": {
        "type": "string"
      },
      "description": "URLs of uploaded evidence files"
    },
    "status": {
      "type": "string",
      "enum": [
        "submitted",
        "under_review",
        "investigating",
        "recovery_in_progress",
        "resolved",
        "closed"
      ],
      "default": "submitted",
      "description": "Current case status"
    },
    "assigned_investigator": {
      "type": "string",
      "description": "Name of assigned investigator"
    },
    "recovery_amount": {
      "type": "number",
      "description": "Amount recovered so far"
    },
    "priority": {
      "type": "string",
      "enum": [
        "low",
        "medium",
        "high",
        "critical"
      ],
      "default": "medium"
    },
    "suspect_info": {
      "type": "string",
      "description": "Any known information about the scammer"
    }
  },
  "required": [
    "full_name",
    "email",
    "scam_type",
    "description",
    "amount_lost"
  ],
  "rls": {
    "create": {},
    "read": {
      "$or": [
        {
          "data.email": "{{user.email}}"
        },
        {
          "user_condition": {
            "role": "admin"
          }
        }
      ]
    },
    "update": {
      "$or": [
        {
          "data.email": "{{user.email}}"
        },
        {
          "user_condition": {
            "role": "admin"
          }
        }
      ]
    },
    "delete": {
      "user_condition": {
        "role": "admin"
      }
    }
  }
}