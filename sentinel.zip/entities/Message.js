{
  "name": "Message",
  "type": "object",
  "properties": {
    "case_id": {
      "type": "string",
      "description": "Associated case ID"
    },
    "sender_name": {
      "type": "string",
      "description": "Name of the message sender"
    },
    "sender_role": {
      "type": "string",
      "enum": [
        "client",
        "investigator",
        "system"
      ],
      "description": "Role of the sender"
    },
    "content": {
      "type": "string",
      "description": "Message content"
    },
    "attachments": {
      "type": "array",
      "items": {
        "type": "string"
      },
      "description": "File attachment URLs"
    },
    "is_read": {
      "type": "boolean",
      "default": false
    }
  },
  "required": [
    "case_id",
    "content",
    "sender_role"
  ]
}